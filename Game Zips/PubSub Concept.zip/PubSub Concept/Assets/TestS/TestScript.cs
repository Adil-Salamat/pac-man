﻿using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using MyScripts;

namespace Tests
{
    public class TestScript
    {
        [UnityTest]
        public IEnumerator TestBallIncreaseSpeed()
        {
            // Get reference to a new ball, it's physics component, and the ball script
            GameObject ball = GameObject.Instantiate(Resources.Load("Ball", typeof(GameObject))) as GameObject;
            Rigidbody2D body = ball.GetComponent<Rigidbody2D>();
            Ball ballScript = ball.GetComponent<Ball>();

            // Wait a frame for it to load
            yield return null;

            // Measure the current velocity
            Vector2 oldVel = body.velocity;
            // Increase the ball's speed using our script
            ballScript.increaseSpeed();
            // Measure the velocity again
            Vector2 newVel = body.velocity;

            // The new velocity should be double the old velocity
            Assert.AreEqual(newVel, oldVel * 2);
        }

        [UnityTest]
        public IEnumerator TestBallDecreaseSpeed()
        {
            // Get reference to a new ball, it's physics component, and the ball script
            GameObject ball = GameObject.Instantiate(Resources.Load("Ball", typeof(GameObject))) as GameObject;
            Rigidbody2D body = ball.GetComponent<Rigidbody2D>();
            Ball ballScript = ball.GetComponent<Ball>();

            // Wait a frame for it to load
            yield return null;

            // Measure the current velocity
            Vector2 oldVel = body.velocity;
            // Decrease the ball's speed using our script
            ballScript.decreaseSpeed();
            // Measure the velocity again
            Vector2 newVel = body.velocity;

            // The new velocity should be half the old velocity
            Assert.AreEqual(newVel, oldVel / 2);
        }

        [UnityTest]
        public IEnumerator TestBallIncreaseSize()
        {
            // Get reference to a new ball and it's transform component
            GameObject ball = GameObject.Instantiate(Resources.Load("Ball", typeof(GameObject))) as GameObject;
            Ball ballScript = ball.GetComponent<Ball>();

            // Wait a frame for it to load
            yield return null;

            // Measure the current size
            Vector2 oldScale = ball.transform.localScale;
            // Increase the ball's size using our script
            ballScript.increaseSize();
            // Measure the size again
            Vector2 newScale = ball.transform.localScale;

            // The new size should be double the old size
            Assert.AreEqual(newScale, oldScale * 2);
        }

        [UnityTest]
        public IEnumerator TestBallDecreaseSize()
        {
            // Get reference to a new ball and it's transform component
            GameObject ball = GameObject.Instantiate(Resources.Load("Ball", typeof(GameObject))) as GameObject;
            Ball ballScript = ball.GetComponent<Ball>();

            // Wait a frame for it to load
            yield return null;

            // Measure the current size
            Vector2 oldScale = ball.transform.localScale;
            // Decrease the ball's size using our script
            ballScript.decreaseSize();
            // Measure the size again
            Vector2 newScale = ball.transform.localScale;

            // The new size should be half the old size
            Assert.AreEqual(newScale, oldScale / 2);
        }
    }
}
