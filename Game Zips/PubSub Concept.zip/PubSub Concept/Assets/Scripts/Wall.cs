﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wall : MonoBehaviour
{
    public string message;

    public delegate void Publish();

    // Messages to publish
    public Publish increaseSpeed;
    public Publish decreaseSpeed;
    public Publish increaseSize;
    public Publish decreaseSize;

    void OnCollisionEnter2D(Collision2D collision)
    {
        // Detect when the ball hits this wall
        if(collision.gameObject.name == "Ball")
        {
            // Check which message this wall publishes
            switch(message)
            {
                case "increaseSpeed":
                    // Publish that message
                    increaseSpeed();
                    break;
                case "decreaseSpeed":
                    decreaseSpeed();
                    break;
                case "increaseSize":
                    increaseSize();
                    break;
                case "decreaseSize":
                    decreaseSize();
                    break;
            }
        }
    }
}
