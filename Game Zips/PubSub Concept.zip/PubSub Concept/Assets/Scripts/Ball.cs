﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace MyScripts
{
    public class Ball : MonoBehaviour
    {
        public Vector2 startVelocity;
        Rigidbody2D body;

        // Start is called before the first frame update
        void Start()
        {
            // Store a reference to this game object's physics component
            body = GetComponent<Rigidbody2D>();

            subscribeToMessages();

            // Give the ball a start velocity specified in the editor
            body.AddForce(startVelocity);
        }

        public void subscribeToMessages()
        {
            // Subscribe to wall 1's increaseSpeed message
            GameObject wall1 = GameObject.Find("Wall 1");
            if(wall1) wall1.GetComponent<Wall>().increaseSpeed += increaseSpeed;

            // Subscribe to wall 2's decreaseSpeed message
            GameObject wall2 = GameObject.Find("Wall 2");
            if (wall2) wall2.GetComponent<Wall>().decreaseSpeed += decreaseSpeed;

            // Subscribe to wall 3's increaseSize message
            GameObject wall3 = GameObject.Find("Wall 3");
            if (wall3) wall3.GetComponent<Wall>().increaseSize += increaseSize;

            // Subscribe to wall 4's increaseSize message
            GameObject wall4 = GameObject.Find("Wall 4");
            if (wall4) wall4.GetComponent<Wall>().decreaseSize += decreaseSize;
        }

        // multiplies the velocity of the ball by 2
        public void increaseSpeed()
        {
            body.velocity *= 2;
        }

        // halfs the velocity of the ball
        public void decreaseSpeed()
        {
            body.velocity /= 2;
        }

        // doubles the size of the ball
        public void increaseSize()
        {
            transform.localScale *= 2;
        }

        // halfs the ball size
        public void decreaseSize()
        {
            transform.localScale /= 2;
        }
    }
}
