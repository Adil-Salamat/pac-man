﻿using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using mega;


namespace Tests
{
    public class TestScript
    {
      
        // this tests the getMad function works

        [UnityTest]
        public IEnumerator getFrogMad()
        {
       
            GameObject frog = GameObject.Instantiate(Resources.Load("frog", typeof(GameObject))) as GameObject;

            yield return new WaitForSeconds(1);

            FrogController frogscript = frog.GetComponent <FrogController> ();

            frogscript.state = FrogController.State.MAD;

            yield return null;


            Assert.AreEqual(frogscript.renderer.sprite, frogscript.sprites[0]);

            yield return null;
        }


        // this tests if the getSad function works, and after a few seconds if the state changes back to MAD
        [UnityTest]
        public IEnumerator getFrogSad()
        {
       
            GameObject frog = GameObject.Instantiate(Resources.Load("frog", typeof(GameObject))) as GameObject;

            yield return new WaitForSeconds(1);

            FrogController frogscript = frog.GetComponent <FrogController> ();

            frogscript.state = FrogController.State.SAD;

            yield return null;


            Assert.AreEqual(frogscript.renderer.sprite, frogscript.sprites[1]);


            yield return new WaitForSeconds(frogscript.reactionTime);

            Assert.AreEqual(frogscript.state, FrogController.State.MAD);

        }


         // this tests if the getDie function works, after a few seconds the sprite should revert back to its orignal state
          [UnityTest]
          public IEnumerator getFrogDead()
        {
       
            GameObject frog = GameObject.Instantiate(Resources.Load("frog", typeof(GameObject))) as GameObject;

            yield return new WaitForSeconds(1);

            FrogController frogscript = frog.GetComponent <FrogController> ();

            frogscript.state = FrogController.State.DEAD;

            yield return null;


            Assert.AreEqual(frogscript.renderer.sprite, frogscript.sprites[2]);


            yield return new WaitForSeconds(frogscript.reactionTime);

            Assert.AreEqual(frogscript.state, FrogController.State.MAD);

        }



    }
}
