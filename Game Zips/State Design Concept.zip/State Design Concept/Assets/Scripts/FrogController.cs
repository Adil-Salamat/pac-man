﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace mega {
public class FrogController : MonoBehaviour
{
    public enum State {
        MAD,
        SAD,
        DEAD
    };
    public State prevState = State.MAD, state = State.MAD;
    public float reactionTime = 5;
    public Sprite[] sprites;
    public SpriteRenderer renderer;
    public GameObject pill, player;
    private IEnumerator gettingMad;

    // Start is called before the first frame update
    void Start()
    {
        renderer = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        // if the states are not the same, enter the if statement
        if (prevState != state)
        {
            // here, the state change takes place
            switch (state)
            {
                case State.MAD:
                    getMad();
                    break;
                case State.SAD:
                    getSad();
                    break;
                case State.DEAD:
                    getDie();
                    break;
            }
            prevState = state;
        }
    }

    // this method is called when the state changes to MAD, the sprite changes
    void getMad()
    {
        renderer.sprite = sprites[0];
    }

    // this method is called when the state changes to SAD, sprite changes and a timer starts
    void getSad()
    {
        renderer.sprite = sprites[1];

        gettingMad = WaitThenGetMad();
        StartCoroutine(gettingMad);
    }

    // this method is called when the state changes to DEAD. sprite changes and the
    // previous timer stops, then the timer is reset and starts again
    void getDie()
    {
        renderer.sprite = sprites[2];

        if(gettingMad != null) StopCoroutine(gettingMad);
        gettingMad = WaitThenGetMad();
        StartCoroutine(gettingMad);
    }

    // this method delets the objects and then remakes them in their original place
    void restartGame()
    {
        Instantiate(pill);

        Destroy(GameObject.FindWithTag("Player"));
        Instantiate(player);
    }

    // this is the timer that resets the frog to MAD if it dies or is in state SAD for a while
    IEnumerator WaitThenGetMad()
    {
        yield return new WaitForSeconds(reactionTime);
        state = State.MAD;
    }

    // this shows the interaction of the player and the frog
    // if the frog is state SAD, it should die with player interaction, so the state becomes DEAD
    // if it is currently in state MAD, the player should die so it resets the game
    void OnTriggerEnter2D(Collider2D col)
    {
        if(state == State.SAD)
        {
            state = State.DEAD;
        }

        if(state == State.MAD)
        {
            restartGame();
        }
    }
}
}
