﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace mega {
public class PlayerController : MonoBehaviour
{
    public int speed = 20;
    private Vector2 direction = Vector2.zero;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // these are just if statements for directional inputs
        // the player moves in the direction indefinatly
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            direction = Vector2.left;

        }
        else if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            direction = Vector2.right;

        }
        else if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            direction = Vector2.up;

        }
        else if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            direction = Vector2.down;
        }

        transform.localPosition += (Vector3)(direction * speed) * Time.deltaTime;
    }

    // this is if the player touches the pill object, it should disapear and the frog state should change
    void OnTriggerEnter2D(Collider2D col)
    {
        if(col.gameObject.tag == "Pill")
        {
            Destroy(col.gameObject);

            GameObject frog = GameObject.FindWithTag("Frog");
            FrogController frogController = frog.GetComponent<FrogController>();
            frogController.state = FrogController.State.SAD;
        }
    }
}
}