﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ghost : MonoBehaviour
{
    public GameObject spawn;
    GameObject currentPoint;

    [Header("Movement")]
    public float normalSpeed = 0.1f;
    public float runningSpeed;
    // How close to be to another point before locking to it
    public float nearPointThreshold = 0.2f;
    
    float speed = 0;
    // A function that runs over time to move the ghost to another point
    IEnumerator movingToPoint = null;
    GameObject pacyman;
    Player pacmanController;

    // Normal and running animations
    [Header("Animations & Sprites")]
    public RuntimeAnimatorController normalAnimator;
    public RuntimeAnimatorController runAnimator;
    public Sprite deadSprite;

    Animator animator;
    SpriteRenderer spriteRenderer;

    // E.g. normal, running, dead
    GhostState state;

    GameController gameController;

    // Runs once when the game starts
    void Start()
    {
        // Load the other components/controllers this script will use later on
        animator = this.GetComponent<Animator>();
        spriteRenderer = this.GetComponent<SpriteRenderer>();

        pacyman = GameObject.FindGameObjectWithTag("Player");
        pacmanController = pacyman.GetComponent<Player>();

        gameController = GameObject.Find("Stage").GetComponent<GameController>();

        currentPoint = spawn;

        // Set the starting state to normal
        state = new NormalState(this);
    }

    // Runs every tick of the game
    void Update()
    {
        // Let the current state figure out how to act
        state.act();
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        // If we collide with the player
        if(collision.gameObject.Equals(pacyman))
        {
            // Let the current state figure out what to do now
            state.onCollideWithPlayer();
        }
    }

    // Any state should have an act function so that we can call it in the update loop
    // regardless of what state we're in
    interface GhostState
    {
        void act();
        void onCollideWithPlayer();
    }

    class NormalState : GhostState
    {
        // Reference to the parent class so we can access its properties
        Ghost ctrl;

        public NormalState(Ghost ctrl)
        {
            this.ctrl = ctrl;
            ctrl.animator.runtimeAnimatorController = ctrl.normalAnimator;
            ctrl.speed = ctrl.normalSpeed;
        }

        // Called by the update loop, runs every tick of the game
        public void act()
        {
            // If we're not moving
            if (ctrl.movingToPoint == null)
            {
                // Get the players location
                GameObject player = ctrl.pacmanController.currentPoint;
                // If we're at the player, we're done
                if (ctrl.currentPoint.Equals(player)) return;
                // If we're not at the player, 
                // use the A* search algorithm to get a path of points to them
                List<GameObject> path = AStar.search(ctrl.currentPoint, player);
                // Move to the next point in the list
                ctrl.movingToPoint = ctrl.moveToPoint(path[1]);
                ctrl.StartCoroutine(ctrl.movingToPoint);
            }
        }

        public void onCollideWithPlayer()
        {
            ctrl.gameController.gameOver();
        }
    }

    class RunningState : GhostState
    {
        // Reference to the parent class so we can access its properties
        Ghost ctrl;
        GameObject furthestPoint;
        IEnumerator waitingToTurnNormal;

        public RunningState(Ghost ctrl)
        {
            this.ctrl = ctrl;
            // Set the animator's controller to the running animation
            ctrl.animator.runtimeAnimatorController = ctrl.runAnimator;
            // Set the speed to the running speed
            ctrl.speed = ctrl.runningSpeed;
            // Calculate the furthest point from where we are now
            furthestPoint = getFurthestPoint();

            waitingToTurnNormal = waitThenTurnNormal();
            ctrl.StartCoroutine(waitingToTurnNormal);
        }

        public void act()
        {
            // If we're not moving
            if (ctrl.movingToPoint == null)
            {
                // If we're at the furthest point, we're done
                if (ctrl.currentPoint.Equals(furthestPoint))
                {
                    ctrl.goBackToNormal();
                    return;
                }

                // If we're not at the furthest point, 
                // use the A* search algorithm to get a path of points to it
                List<GameObject> path = AStar.search(ctrl.currentPoint, furthestPoint);
                // Move to the next point in the list
                ctrl.movingToPoint = ctrl.moveToPoint(path[1]);
                ctrl.StartCoroutine(ctrl.movingToPoint);
            }
        }

        public void onCollideWithPlayer()
        {
            ctrl.StopCoroutine(waitingToTurnNormal);

            ctrl.state = new DeadState(ctrl);
        }

        IEnumerator waitThenTurnNormal()
        {
            yield return new WaitForSeconds(5);

            ctrl.goBackToNormal();
        }

        // Measures using Euclidean distance
        GameObject getFurthestPoint()
        {
            GameObject[] points = GameObject.FindGameObjectsWithTag("Point");
            
            GameObject furthestPoint = null;
            float furthestDistance = 0;

            // Go over each point on the map
            foreach(GameObject point in points)
            {
                // If it's further than anything we've seen before, take note of it
                float distance = Vector3.Distance(point.transform.localPosition, ctrl.gameObject.transform.localPosition);
                if(distance > furthestDistance)
                {
                    furthestDistance = distance;
                    furthestPoint = point;
                }
            }

            return furthestPoint;
        }
    }

    class DeadState : GhostState
    {
        // Reference to the parent class so we can access its properties
        Ghost ctrl;

        public DeadState(Ghost ctrl)
        {
            this.ctrl = ctrl;
            ctrl.speed = ctrl.normalSpeed;
            ctrl.animator.runtimeAnimatorController = null;
            ctrl.spriteRenderer.sprite = ctrl.deadSprite;
        }

        public void act()
        {
            // If we're not moving
            if (ctrl.movingToPoint == null)
            {
                // If we're at the spawn point, we're done
                if (ctrl.currentPoint.Equals(ctrl.spawn))
                {
                    ctrl.goBackToNormal();
                    return;
                }

                // If we're not at the spawn point, 
                // use the A* search algorithm to get a path of points to it
                List<GameObject> path = AStar.search(ctrl.currentPoint, ctrl.spawn);
                // Move to the next point in the list
                ctrl.movingToPoint = ctrl.moveToPoint(path[1]);
                ctrl.StartCoroutine(ctrl.movingToPoint);
            }
        }

        public void onCollideWithPlayer()
        {

        }
    }

    public void startRunning()
    {
        state = new RunningState(this);
    }

    public void goBackToNormal()
    {
        state = new NormalState(this);
    }

    // A function that runs over time to move the ghost to another point
    IEnumerator moveToPoint(GameObject point)
    {
        // Store the x values of both objects for comparison
        float pointVal = point.transform.localPosition.x;
        float myVal = transform.localPosition.x;

        // If they're x value is the same
        bool isVertical = pointVal == myVal ? true : false;
        // Then we must be looking for a change in y value
        if (isVertical)
        {
            pointVal = point.transform.localPosition.y;
            myVal = transform.localPosition.y;
        }

        bool isNear = myVal > (pointVal - nearPointThreshold) && myVal < (pointVal + nearPointThreshold);
        // While we're not near the target
        while (!isNear)
        {
            // Adjust the position value
            if (myVal < pointVal) myVal += speed;
            else myVal -= speed;

            // Apply it 
            setXorY(isVertical, myVal);
            
            // Re-evaluate how close we are after moving
            isNear = myVal > (pointVal - nearPointThreshold) && myVal < (pointVal + nearPointThreshold);
            // Go to the next frame
            yield return null;
        }

        // When we're close enough, round off the position and lock to it
        lockToPoint(point);
    }

    void setXorY(bool isYAxis, float value)
    {
        // Can't update the vector properties directly
        // So we change the whole vector
        Vector3 pos = transform.localPosition;
        if (isYAxis) pos.y = value;
        else pos.x = value;
        transform.localPosition = pos;
    }

    void lockToPoint(GameObject point)
    {
        // Set the positions to be exactly the same
        transform.localPosition = point.transform.localPosition;
        // Update the point location system
        currentPoint = point;
        // Set that we're not moving anymore
        movingToPoint = null;
    }

    public void reset()
    {
        StopAllCoroutines();

        lockToPoint(spawn);
    }

    // Represents a node in an A* search
    class Node
    {
        // Holds the game object it represents
        public GameObject gameObject;
        public Node parent = null;
        // g is the total distance via this node on a path
        // h is the Euclidean distance to the goal
        public float g = 0, h = 0;
        // f is the total cost of going via this node on a path
        public float f
        {
            get
            {
                return g + h;
            }
        }

        public Node(GameObject gameObject)
        {
            this.gameObject = gameObject;
        }

        // Distance from this node to another game object
        public float distance(GameObject gameObject)
        {
            Vector3 aPos = this.gameObject.transform.localPosition;
            Vector3 bPos = gameObject.transform.localPosition;
            return Vector3.Distance(aPos, bPos);
        }

        // From a list of nodes, get the node with the lowest overall cost on a path
        public static Node getLowestFNode(List<Node> nodes)
        {
            float lowestF = float.MaxValue;
            Node q = null;
            // Go over each node in the list
            foreach (Node node in nodes)
            {
                // If it's cheaper than anything we've seen before, take note of it
                if (node.f < lowestF)
                {
                    lowestF = node.f;
                    q = node;
                }
            }
            return q;
        }

        // Returns a list of nodes connected to this node
        public List<Node> getSuccessors()
        {
            GameObject[] friends = this.gameObject.GetComponent<Point>().friends;
            List<Node> successors = new List<Node>();

            foreach (GameObject friend in friends)
            {
                Node successor = new Node(friend);
                // Sets each ones parent to this node
                successor.parent = this;
                successors.Add(successor);
            }
            
            return successors;
        }

        // Given a list of nodes and a game object, returns the node that wraps the game object
        public static Node fromGameObject(List<Node> nodes, GameObject gameObject)
        {
            Node result = null;
            foreach (Node node in nodes)
            {
                if (node.gameObject.Equals(gameObject))
                {
                    result = node;
                    break;
                }
            }
            return result;
        }
    }
    
    // Class that stores all the functions related to the A* search
    class AStar
    {
        // Returns a path of game objects, in order, from start to end
        public static List<GameObject> search(GameObject start, GameObject end)
        {
            // A list of nodes to check
            List<Node> open = new List<Node>();

            // A list of nodes we've expanded
            List<Node> closed = new List<Node>();
            Node startNode = new Node(start);
            // Begin by expanding the start node
            open.Add(startNode);

            // While there are still nodes to check
            while (open.Count > 0)
            {
                // Get the cheapest looking option from the nodes to check list
                Node q = Node.getLowestFNode(open);
                // Take it off that list
                open.Remove(q);
                // Get all connecting nodes
                List<Node> successors = q.getSuccessors();

                bool goalFound = false;
                // Go through each connecting node
                foreach (Node successor in successors)
                {
                    // If this node is the end
                    if (successor.gameObject.Equals(end))
                    {
                        goalFound = true;
                        // Add it to the list of expanded (output) nodes
                        closed.Add(successor);
                        break;
                    }

                    // If this is not the end node,
                    // Calculate the total cost of getting to this node along the current path of parent nodes
                    successor.g = q.g + successor.distance(q.gameObject);
                    // Calculate the Euclidean distance from this node to the goal
                    successor.h = successor.distance(end);

                    // If a better route to this node exists in any list, skip it
                    if (betterRouteExists(successor, closed) || betterRouteExists(successor, open)) continue;

                    // Otherwise, add it to the list of nodes to check
                    open.Add(successor);
                }
                // Add the parent node to the expanded list, we're done with it
                closed.Add(q);

                if (goalFound) break;
            }
            // Find the route, given all of the nodes we've expanded before returning
            return getRoute(closed, start, end);
        }

        static bool betterRouteExists(Node newNode, List<Node> nodes)
        {
            bool result = false;
            foreach (Node node in nodes)
            {
                // Find a node that represents the same game object
                if (node.gameObject.Equals(newNode.gameObject))
                {
                    // If its cheaper to go via that node than this one
                    if (node.f < newNode.f)
                    {
                        // Then a better route exists
                        result = true;
                        break;
                    }
                }
            }
            return result;
        }

        // Given a list of nodes, return just the ones that create a chain of parents from start to end
        static List<GameObject> getRoute(List<Node> nodes, GameObject start, GameObject end)
        {
            List<Node> route = new List<Node>();
            // Find the end game objects representation as a node
            Node current = Node.fromGameObject(nodes, end);
            // While we're not looking at the start
            while (!current.gameObject.Equals(start))
            {
                // Add this node to the route
                route.Add(current);
                // Next time check this ones parent
                current = current.parent;
            }
            
            // Add the start node to the list
            Node startNode = Node.fromGameObject(nodes, start);
            route.Add(startNode);

            // Convert the list of nodes to a list of game objects
            List<GameObject> gameObjects = new List<GameObject>();
            foreach (Node node in route)
            {
                gameObjects.Add(node.gameObject);
            }

            // Reverse the list so it goes from start to end, and then return the result
            return reverseList(gameObjects);
        }

        static List<GameObject> reverseList(List<GameObject> list)
        {
            List<GameObject> reversedList = new List<GameObject>();
            for (int i = list.Count - 1; i >= 0; --i)
            {
                reversedList.Add(list[i]);
            }
            return reversedList;
        }

        // Used for debugging
        public static void printRoute(List<GameObject> route)
        {
            string routeString = "Route:\n";
            foreach (GameObject point in route)
            {
                routeString += point.name + "\n";
            }
            Debug.Log(routeString);
        }
    }
}