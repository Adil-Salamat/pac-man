﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pellet : MonoBehaviour
{
    public int value;
    public bool isSuper;
    GameObject player;
    GameController gameController;
    Ghost[] ghosts;

    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        gameController = GameObject.Find("Stage").GetComponent<GameController>();
        
        GameObject[] ghostGameObjects = GameObject.FindGameObjectsWithTag("Ghost");
        ghosts = new Ghost[ghostGameObjects.Length];
        for(int i = 0; i < ghostGameObjects.Length; ++i)
        {
            ghosts[i] = ghostGameObjects[i].GetComponent<Ghost>();
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject == player)
        {
            gameController.pelletEaten(value);

            this.gameObject.SetActive(false);

            if (gameController.PelletsLeft <= 0) gameController.resetLevel();

            if(isSuper)
            {
                foreach(Ghost ghost in ghosts)
                {
                    ghost.startRunning();
                }
            }
        }
    }
}
