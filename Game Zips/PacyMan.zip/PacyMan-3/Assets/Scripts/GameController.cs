﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour
{
    public Text screenText;

    int score = 0;
    int pelletsLeft = 0;
    public int PelletsLeft
    {
        get
        {
            return pelletsLeft;
        }
    }

    GameObject[] pellets;
    Player player;
    Ghost[] ghosts;

    // Start is called before the first frame update
    void Start()
    {
        pellets = GameObject.FindGameObjectsWithTag("Pellet");
        pelletsLeft = pellets.Length;

        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();

        // Get all ghost scripts
        GameObject[] ghostGameObjects = GameObject.FindGameObjectsWithTag("Ghost");
        ghosts = new Ghost[ghostGameObjects.Length];
        for(int i = 0; i < ghostGameObjects.Length; ++i)
        {
            ghosts[i] = ghostGameObjects[i].GetComponent<Ghost>();
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void gameOver()
    {
        resetLevel();

        score = 0;

        foreach(Ghost ghost in ghosts)
        {
            ghost.reset();
        }
    }

    public void resetLevel()
    {
        pelletsLeft = pellets.Length;

        foreach(GameObject pellet in pellets)
        {
            pellet.SetActive(true);
        }

        player.reset();
    }

    public void pelletEaten(int value)
    {
        pelletsLeft -= 1;

        score += value;

        screenText.text = "Score: " + score;
    }
}
