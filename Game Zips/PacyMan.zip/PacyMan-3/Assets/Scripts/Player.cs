﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public GameObject currentPoint;
    public float speed = 0.1f;
    public float nearFriendThreshold = 0.2f;

    private IEnumerator movingToFriend = null;
    private GameObject targetFriend;
    private Direction movingDir;
    private Direction dir;

    private enum Direction
    {
        UP,
        DOWN,
        LEFT,
        RIGHT
    }

    private Vector3 startPos;
    private GameObject startPoint;

    // Start is called before the first frame update
    void Start()
    {
        startPos = transform.localPosition;
        startPoint = currentPoint;
    }

    // Update is called once per frame
    void Update()
    {
        // Get the desired direction based on the user input
        if (Input.GetKeyDown(KeyCode.UpArrow)) dir = Direction.UP;
        if (Input.GetKeyDown(KeyCode.DownArrow)) dir = Direction.DOWN;
        if (Input.GetKeyDown(KeyCode.LeftArrow)) dir = Direction.LEFT;
        if (Input.GetKeyDown(KeyCode.RightArrow)) dir = Direction.RIGHT;

        // See if we have any friends we can reach in the direction we want to go
        GameObject friendInDir = getFriendInDir(currentPoint);

        // If we do and we're not already moving
        if (friendInDir != null && movingToFriend == null)
        {
            // Start moving to that friend
            movingToFriend = moveToPoint(friendInDir);
            StartCoroutine(movingToFriend);
        }

        // If we're already moving and we want to move in the opposite direction
        // This allows us to turn around mid way
        if(movingToFriend != null && isOppositeDir(dir, movingDir))
        {
            // Stop moving in the first direction
            StopCoroutine(movingToFriend);
            // Start heading back
            movingToFriend = moveToPoint(currentPoint);
            StartCoroutine(movingToFriend);
        }

        // We check ahead of time if, when we reach the next point, we can move in a new direction
        // If we can't, just keep going in the direction we're already moving in
        // This allows us to not stop in the middle of an open path
        if (targetFriend != null && getFriendInDir(targetFriend) == null) dir = movingDir;
    }

    public void reset()
    {
        StopAllCoroutines();

        lockToFriend(startPoint);
    }

    private IEnumerator moveToPoint(GameObject friend)
    {
        movingDir = dir;
        rotateFace(movingDir);

        targetFriend = friend;

        bool isVertical = movingDir == Direction.UP || movingDir == Direction.DOWN;

        float friendVal = friend.transform.localPosition.x;
        float myVal = transform.localPosition.x;

        if (isVertical)
        {
            friendVal = friend.transform.localPosition.y;
            myVal = transform.localPosition.y;
        }

        bool isNear = myVal > (friendVal - nearFriendThreshold) && myVal < (friendVal + nearFriendThreshold);

        while (!isNear)
        {
            if (myVal < friendVal) myVal += speed;
            else myVal -= speed;

            setXorY(isVertical, myVal);

            isNear = myVal > (friendVal - nearFriendThreshold) && myVal < (friendVal + nearFriendThreshold);

            yield return null;
        }

        lockToFriend(friend);
    }

    private GameObject getFriendInDir(GameObject point)
    {
        GameObject[] friends = point.GetComponent<Point>().friends;
        GameObject result = null;

        float pointX = point.transform.localPosition.x;
        float pointY = point.transform.localPosition.y;

        for (int i = 0; i < friends.Length; ++i)
        {
            float friendX = friends[i].transform.localPosition.x;
            float friendY = friends[i].transform.localPosition.y;

            if (dir == Direction.UP && pointY < friendY)
            {
                result = friends[i];
                break;
            }
            if (dir == Direction.DOWN && pointY > friendY)
            {
                result = friends[i];
                break;
            }
            if (dir == Direction.LEFT && pointX > friendX)
            {
                result = friends[i];
                break;
            }
            if (dir == Direction.RIGHT && pointX < friendX)
            {
                result = friends[i];
                break;
            }
        }

        return result;
    }

    private void setXorY(bool isVertical, float value)
    {
        Vector3 pos = transform.localPosition;
        if (isVertical) pos.y = value;
        else pos.x = value;
        transform.localPosition = pos;
    }

    private void lockToFriend(GameObject friend)
    {
        transform.localPosition = friend.transform.localPosition;

        currentPoint = friend;

        targetFriend = null;

        movingToFriend = null;
    }

    private bool isOppositeDir(Direction dirA, Direction dirB)
    {
        bool result = false;
        
        if (dirA == Direction.UP && dirB == Direction.DOWN || 
            dirB == Direction.UP && dirA == Direction.DOWN) result = true;
        
        if (dirA == Direction.RIGHT && dirB == Direction.LEFT || 
            dirB == Direction.RIGHT && dirA == Direction.LEFT) result = true;
        
        return result;
    }

    private void rotateFace(Direction direction)
    {
        Vector3 rot = transform.localEulerAngles;
        
        switch(direction)
        {
            case Direction.UP:
                rot.z = 90;
                break;
            case Direction.DOWN:
                rot.z = 270;
                break;
            case Direction.LEFT:
                rot.z = 180;
                break;
            case Direction.RIGHT:
                rot.z = 0;
                break;
        }
        
        transform.localEulerAngles = rot;
    }
}