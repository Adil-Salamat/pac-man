﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour
{
    public Text screenText;

    int score = 0;
    int pelletsLeft = 0;
    // Pellets left count, with a C# property
    // to only allow changes to it inside the game controller
    // Outside game objects can only read it
    public int PelletsLeft
    {
        get
        {
            return pelletsLeft;
        }
    }

    GameObject[] pellets;
    Ghost[] ghosts;

    // List of constants the define the events available
    public enum Event
    {
        RESET
    };
    // A method holder so that we can call any method given to the game controller
    // regardless of its name, as long as it has the same signature
    public delegate void OnEvent();
    // A list of those methods given to the game controller upon subscription (the listeners)
    List<OnEvent> listeners = new List<OnEvent>();
    // A corresponding list of the events the listeners are listening for
    // listeners[i] is listening for events[i]
    // These are all the same right now, but it accommodates adding more events
    List<Event> events = new List<Event>();

    void Start()
    {
        // Get all the pellets
        pellets = GameObject.FindGameObjectsWithTag("Pellet");
        // Count them
        pelletsLeft = pellets.Length;

        // Get all ghost scripts
        GameObject[] ghostGameObjects = GameObject.FindGameObjectsWithTag("Ghost");
        ghosts = new Ghost[ghostGameObjects.Length];
        for(int i = 0; i < ghostGameObjects.Length; ++i)
        {
            ghosts[i] = ghostGameObjects[i].GetComponent<Ghost>();
        }
    }

    // Subscribe to event "eventConst" so that onEvent is called when the event happens
    public void subscribe(Event eventConst, OnEvent onEvent)
    {
        listeners.Add(onEvent);
        events.Add(eventConst);
    }

    // Call all of the listeners who are listening for event "eventConst"
    public void publish(Event eventConst)
    {
        // Get the indexes of all the listeners who are listening for this event
        List<int> listenerIds = new List<int>();

        for(int i = 0; i < events.Count; ++i)
        {
            if(events[i] == eventConst)
            {
                listenerIds.Add(i);
            }
        }

        // Call them
        foreach(OnEvent onEvent in listeners)
        {
            onEvent();
        }
    }

    public void gameOver()
    {
        resetLevel();

        score = 0;
    }

    public void resetLevel()
    {
        // The number of pellets left on the map should now be all the pellets
        pelletsLeft = pellets.Length;

        // Tell any game objects that are listening that the game is resetting
        publish(Event.RESET);
    }

    public void pelletEaten(int value)
    {
        pelletsLeft -= 1;

        score += value;

        // Display the score on the screen
        screenText.text = "Score: " + score;
    }
}
