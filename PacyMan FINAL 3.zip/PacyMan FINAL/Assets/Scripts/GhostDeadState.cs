﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GhostDeadState : MonoBehaviour, IGhostState
{
    [Range(0, 200)]
    public float speedPercent = 100;
    public Sprite deadSprite;
    
    float deadSpeed = 0;
    
    SpriteRenderer spriteRenderer;
    Animator animator;
    
    bool initialised = false;
    
    Ghost ghost;

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();
        ghost = GetComponent<Ghost>();
        
        // Set the speed whilst dead to be some set percentage of the normal speed
        deadSpeed = ghost.normalSpeed * (speedPercent / 100);
    }

    void init()
    {
        // Remove the animation
        animator.runtimeAnimatorController = null;
        
        // Set the sprite to a still image
        spriteRenderer.sprite = deadSprite;
        
        ghost.Speed = deadSpeed;
        
        initialised = true;
    }

    public void act()
    {
        if (!initialised) init();

        // If this ghost isn't moving
        if (ghost.movingToPoint == null)
        {
            // If its at the spawn point
            if (ghost.CurrentPoint.Equals(ghost.spawn))
            {
                initialised = false;

                // Respawn
                ghost.goBackToNormal();
                return;
            }

            // Otherwise find a path to the spawn
            List<GameObject> path = AStar.search(ghost.CurrentPoint, ghost.spawn);
            
            // Move to the first point on that path
            ghost.movingToPoint = ghost.moveToPoint(path[1]);
            StartCoroutine(ghost.movingToPoint);
        }
    }

    public void onCollideWithPlayer()
    {

    }
}
