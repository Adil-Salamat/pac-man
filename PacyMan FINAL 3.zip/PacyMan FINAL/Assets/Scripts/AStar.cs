﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Class that stores all the functions related to the A* search
public class AStar
{
    // Returns a path of game objects, in order, from start to end
    public static List<GameObject> search(GameObject start, GameObject end)
    {
        // A list of nodes to check
        List<Node> open = new List<Node>();

        // A list of nodes we've expanded
        List<Node> closed = new List<Node>();
        Node startNode = new Node(start);
        // Begin by expanding the start node
        open.Add(startNode);

        // While there are still nodes to check
        while (open.Count > 0)
        {
            // Get the cheapest looking option from the nodes to check list
            Node q = Node.getLowestFNode(open);
            // Take it off that list
            open.Remove(q);
            // Get all connecting nodes
            List<Node> successors = q.getSuccessors();

            bool goalFound = false;
            // Go through each connecting node
            foreach (Node successor in successors)
            {
                // If this node is the end
                if (successor.gameObject.Equals(end))
                {
                    goalFound = true;
                    // Add it to the list of expanded (output) nodes
                    closed.Add(successor);
                    break;
                }

                // If this is not the end node,
                // Calculate the total cost of getting to this node along the current path of parent nodes
                successor.g = q.g + successor.distance(q.gameObject);
                // Calculate the Euclidean distance from this node to the goal
                successor.h = successor.distance(end);

                // If a better route to this node exists in any list, skip it
                if (betterRouteExists(successor, closed) || betterRouteExists(successor, open)) continue;

                // Otherwise, add it to the list of nodes to check
                open.Add(successor);
            }
            // Add the parent node to the expanded list, we're done with it
            closed.Add(q);

            if (goalFound) break;
        }
        // Find the route, given all of the nodes we've expanded before returning
        return getRoute(closed, start, end);
    }

    static bool betterRouteExists(Node newNode, List<Node> nodes)
    {
        bool result = false;
        foreach (Node node in nodes)
        {
            // Find a node that represents the same game object
            if (node.gameObject.Equals(newNode.gameObject))
            {
                // If its cheaper to go via that node than this one
                if (node.f < newNode.f)
                {
                    // Then a better route exists
                    result = true;
                    break;
                }
            }
        }
        return result;
    }

    // Given a list of nodes, return just the ones that create a chain of parents from start to end
    static List<GameObject> getRoute(List<Node> nodes, GameObject start, GameObject end)
    {
        List<Node> route = new List<Node>();
        // Find the end game objects representation as a node
        Node current = Node.fromGameObject(nodes, end);
        // While we're not looking at the start
        while (!current.gameObject.Equals(start))
        {
            // Add this node to the route
            route.Add(current);
            // Next time check this ones parent
            current = current.parent;
        }

        // Add the start node to the list
        Node startNode = Node.fromGameObject(nodes, start);
        route.Add(startNode);

        // Convert the list of nodes to a list of game objects
        List<GameObject> gameObjects = new List<GameObject>();
        foreach (Node node in route)
        {
            gameObjects.Add(node.gameObject);
        }

        // Reverse the list so it goes from start to end, and then return the result
        return reverseList(gameObjects);
    }

    static List<GameObject> reverseList(List<GameObject> list)
    {
        List<GameObject> reversedList = new List<GameObject>();
        for (int i = list.Count - 1; i >= 0; --i)
        {
            reversedList.Add(list[i]);
        }
        return reversedList;
    }

    // Used for debugging
    public static void printRoute(List<GameObject> route)
    {
        string routeString = "Route:\n";
        foreach (GameObject point in route)
        {
            routeString += point.name + "\n";
        }
        Debug.Log(routeString);
    }
}