﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public GameObject currentPoint;
    public float speed = 0.1f;
    public float positionThreshold = 0.2f;

    GameObject startPoint;
    GameObject targetPoint;
    IEnumerator movingToPoint = null;
    
    enum Direction
    {
        UP,
        DOWN,
        LEFT,
        RIGHT
    }
    Direction dir;
    Direction movingDir;

    // Start is called before the first frame update
    void Start()
    {
        startPoint = currentPoint;

        // Get the game controller
        GameController gameController = GameObject.Find("Stage").GetComponent<GameController>();
        
        // Listen for the reset event and call the players reset method once it is fired
        gameController.subscribe(GameController.Event.RESET, reset);
    }

    // Update is called once per frame
    void Update()
    {
        // Get the desired direction based on the user input
        if (Input.GetKeyDown(KeyCode.UpArrow)) dir = Direction.UP;
        if (Input.GetKeyDown(KeyCode.DownArrow)) dir = Direction.DOWN;
        if (Input.GetKeyDown(KeyCode.LeftArrow)) dir = Direction.LEFT;
        if (Input.GetKeyDown(KeyCode.RightArrow)) dir = Direction.RIGHT;

        // See if we have any friends we can reach in the direction we want to go
        GameObject friendInDir = getFriendInDir(currentPoint);

        // If we do and we're not already moving
        if (friendInDir != null && movingToPoint == null)
        {
            // Start moving to that friend
            movingToPoint = moveToPoint(friendInDir);
            StartCoroutine(movingToPoint);
        }

        // If we're already moving and we want to move in the opposite direction
        // This allows us to turn around mid way
        if(movingToPoint != null && isOppositeDir(dir, movingDir))
        {
            // Stop moving in the first direction
            StopCoroutine(movingToPoint);
            // Start heading back
            movingToPoint = moveToPoint(currentPoint);
            StartCoroutine(movingToPoint);
        }

        // We check ahead of time if, when we reach the next point, we can move in a new direction
        // If we can't, just keep going in the direction we're already moving in
        // This allows us to not stop in the middle of an open path
        if (targetPoint != null && getFriendInDir(targetPoint) == null) dir = movingDir;
    }

    public void reset()
    {
        // Stop any movement
        StopAllCoroutines();

        // Fix the position to the starting point
        lockToPoint(startPoint);
    }

    // Moves the player to a given point over time
    IEnumerator moveToPoint(GameObject point)
    {
        // Lock in the direction we're moving at this point in time
        movingDir = dir;

        rotateFace(movingDir);

        targetPoint = point;

        // Check to see if the distance between the player and the target is less than a threshold
        bool isEqualPos = Vector3.Distance(transform.localPosition, point.transform.localPosition) < positionThreshold;

        // If its not
        while (!isEqualPos)
        {
            // Update the players position to move towards the point at speed
            transform.localPosition = Vector3.MoveTowards(transform.localPosition, point.transform.localPosition, speed);

            // Check if the player is close enough again
            isEqualPos = Vector3.Distance(transform.localPosition, point.transform.localPosition) < positionThreshold;

            // Go to the next frame
            yield return null;
        }

        // When the player is close enough, just lock it to the exact position
        lockToPoint(point);
    }

    // Locks the player to the exact position of point
    void lockToPoint(GameObject point)
    {
        transform.localPosition = point.transform.localPosition;

        currentPoint = point;

        // Stopped moving
        movingToPoint = null;

        // No target as the player is already at it
        targetPoint = null;
    }

    // Given a point, return the connecting points who are also in the
    // same direction the player is looking
    GameObject getFriendInDir(GameObject point)
    {
        GameObject[] friends = point.GetComponent<Point>().friends;
        GameObject result = null;

        float pointX = point.transform.localPosition.x;
        float pointY = point.transform.localPosition.y;

        // For each connecting point
        for (int i = 0; i < friends.Length; ++i)
        {
            float friendX = friends[i].transform.localPosition.x;
            float friendY = friends[i].transform.localPosition.y;

            // If the player is going up and its also below the connecting point, return it
            if (dir == Direction.UP && pointY < friendY)
            {
                result = friends[i];
                break;
            }
            // If the player is going down and its also above the connecting point, return it
            if (dir == Direction.DOWN && pointY > friendY)
            {
                result = friends[i];
                break;
            }
            // If the player is going left and its also to the right of the connecting point, return it
            if (dir == Direction.LEFT && pointX > friendX)
            {
                result = friends[i];
                break;
            }
            // If the player is going right and its also to the left of the connecting point, return it
            if (dir == Direction.RIGHT && pointX < friendX)
            {
                result = friends[i];
                break;
            }
        }

        return result;
    }

    // Given two constant directions, returns true if they're opposing
    bool isOppositeDir(Direction dirA, Direction dirB)
    {
        bool result = false;
        
        if (dirA == Direction.UP && dirB == Direction.DOWN || 
            dirB == Direction.UP && dirA == Direction.DOWN) result = true;
        
        if (dirA == Direction.RIGHT && dirB == Direction.LEFT || 
            dirB == Direction.RIGHT && dirA == Direction.LEFT) result = true;
        
        return result;
    }

    // Sets the angle of the player given a constant direction
    void rotateFace(Direction direction)
    {
        Vector3 rot = transform.localEulerAngles;
        
        // Get an angle given a constant, e.g. "UP" maps to 90deg
        switch(direction)
        {
            case Direction.UP:
                rot.z = 90;
                break;
            case Direction.DOWN:
                rot.z = 270;
                break;
            case Direction.LEFT:
                rot.z = 180;
                break;
            case Direction.RIGHT:
                rot.z = 0;
                break;
        }
        
        transform.localEulerAngles = rot;
    }
}