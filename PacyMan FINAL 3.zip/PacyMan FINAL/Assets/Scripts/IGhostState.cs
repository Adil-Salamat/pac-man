﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Any state should have an act function (for example) so that we can call it in the update loop
// regardless of what specific state we're in
public interface IGhostState
{
    void act();
    void onCollideWithPlayer();
}