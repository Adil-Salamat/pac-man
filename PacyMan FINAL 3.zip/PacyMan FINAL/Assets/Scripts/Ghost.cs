﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ghost : MonoBehaviour, IGhostState
{
    public GameObject spawn;
    public float normalSpeed = 0.1f;
    public RuntimeAnimatorController normalAnimation;
    public float positionThreshold = 0.2f;

    float speed = 0;
    public float Speed
    {
        set
        {
            speed = value;
        }
    }

    GameObject currentPoint;
    public GameObject CurrentPoint
    {
        get
        {
            return currentPoint;
        }
    }

    [HideInInspector()]
    public IEnumerator movingToPoint = null;

    // Polymorphism - treating possibly different states as one to reduce duplication
    IGhostState state;
    GhostRunState runState;
    GhostDeadState deadState;

    GameObject pacman;
    Player pacmanController;
    GameController gameController;
    Animator animator;

    bool stateInitialised = false;

    void Start()
    {
        // Get the other states
        deadState = GetComponent<GhostDeadState>();
        runState = GetComponent<GhostRunState>();

        // Get the animation controller
        animator = GetComponent<Animator>();
        
        // Get pacman and its controller
        pacman = GameObject.FindGameObjectWithTag("Player");
        pacmanController = pacman.GetComponent<Player>();

        // Get the game controller
        gameController = GameObject.Find("Stage").GetComponent<GameController>();

        // Subscribe to the reset event
        gameController.subscribe(GameController.Event.RESET, reset);

        currentPoint = spawn;

        // Set the initial state to this normal state
        state = this;
    }

    void Update()
    {
        // Act how the current state should act
        state.act();
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        // If this ghost has collided with pacman
        if(collision.gameObject.Equals(pacman))
        {
            // Let the state handle what should happen
            state.onCollideWithPlayer();
        }
    }

    // Initialise the state
    void init()
    {
        // Set the animation to the normal animation
        animator.runtimeAnimatorController = normalAnimation;

        speed = normalSpeed;
        
        stateInitialised = true;
    }

    public void act()
    {
        if (!stateInitialised) init();

        // If the ghost is not moving
        if (movingToPoint == null)
        {
            // Get the players current position
            GameObject player = pacmanController.currentPoint;
            
            // If this ghost is already at the player then its done
            if (currentPoint.Equals(player)) return;
            
            // Otherwise, find a path to the player
            // As this is re-run every frame, it doesn't matter if pacman moves
            // because the path will just be re-evaluated every time anyway
            List<GameObject> path = AStar.search(currentPoint, player);
            
            // Start moving to the next point in that list
            movingToPoint = moveToPoint(path[1]);
            StartCoroutine(movingToPoint);
        }
    }

    public void onCollideWithPlayer()
    {
        gameController.gameOver();
    }

    public void startRunning()
    {
        state = runState;
    }

    public void die()
    {
        state = deadState;
    }

    public void goBackToNormal()
    {
        // De-initialise so that initialisation can occur when this state starts
        stateInitialised = false;
        state = this;
    }

    // Same as player movement method
    public IEnumerator moveToPoint(GameObject point)
    {
        bool isEqualPos = Vector3.Distance(transform.localPosition, point.transform.localPosition) < positionThreshold;

        while (!isEqualPos)
        {
            transform.localPosition = Vector3.MoveTowards(transform.localPosition, point.transform.localPosition, speed);

            isEqualPos = Vector3.Distance(transform.localPosition, point.transform.localPosition) < positionThreshold;

            yield return null;
        }

        lockToPoint(point);
    }

    // Same as player lock to point method
    void lockToPoint(GameObject point)
    {
        transform.localPosition = point.transform.localPosition;
        
        currentPoint = point;
        
        movingToPoint = null;
    }

    // Same as player reset method
    public void reset()
    {
        StopAllCoroutines();

        lockToPoint(spawn);
    }
}