﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GhostRunState : MonoBehaviour, IGhostState
{
    [Range(0, 200)]
    public float speedPercent = 100;
    public RuntimeAnimatorController runAnimation;
    
    float runningSpeed;
    
    GameObject furthestPoint;
    IEnumerator waitingToTurnNormal;
    
    Animator animator;
    
    bool initialised = false;
    
    Ghost ghost;

    void Start()
    {
        animator = GetComponent<Animator>();
        ghost = GetComponent<Ghost>();
        
        runningSpeed = ghost.normalSpeed * (speedPercent / 100);
    }

    void init()
    {
        animator.runtimeAnimatorController = runAnimation;
        
        ghost.Speed = runningSpeed;
        
        // Get the furthest point from this ghost the moment it starts running
        furthestPoint = getFurthestPoint();
        
        initialised = true;

        // Begin a countdown to return to normal
        waitingToTurnNormal = waitThenTurnNormal();
        StartCoroutine(waitingToTurnNormal);
    }

    public void act()
    {
        if (!initialised) init();

        if (ghost.movingToPoint == null)
        {
            // If this ghost has reached the furthest point
            // Return it to normal
            if (ghost.CurrentPoint.Equals(furthestPoint))
            {
                initialised = false;

                ghost.goBackToNormal();

                return;
            }

            // Otherwise, pathfind to the furthest point
            List<GameObject> path = AStar.search(ghost.CurrentPoint, furthestPoint);
            
            ghost.movingToPoint = ghost.moveToPoint(path[1]);
            StartCoroutine(ghost.movingToPoint);
        }
    }

    public void onCollideWithPlayer()
    {
        initialised = false;

        // If we collide with the player
        // Stop any other state transitions
        StopCoroutine(waitingToTurnNormal);
        
        // Go into the dead state
        ghost.die();
    }

    // Wait for 5 seconds and then turn back to the normal state
    IEnumerator waitThenTurnNormal()
    {
        yield return new WaitForSeconds(5);
        
        initialised = false;
        
        ghost.goBackToNormal();
    }

    GameObject getFurthestPoint()
    {
        // Get all the points on the map
        GameObject[] points = GameObject.FindGameObjectsWithTag("Point");

        GameObject furthestPoint = null;
        float furthestDistance = 0;

        // Go through each point
        foreach (GameObject point in points)
        {
            // See how far away it is
            float distance = Vector3.Distance(point.transform.localPosition, gameObject.transform.localPosition);
            
            // If its further than anything we've seen before
            if (distance > furthestDistance)
            {
                // Take note of it
                furthestDistance = distance;
                furthestPoint = point;
            }
        }

        return furthestPoint;
    }
}
