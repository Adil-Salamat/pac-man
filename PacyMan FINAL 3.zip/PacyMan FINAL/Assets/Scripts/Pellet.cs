﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pellet : MonoBehaviour
{
    public int value;
    public bool isSuper;

    GameObject player;
    GameController gameController;
    Ghost[] ghosts;

    void Start()
    {
        // Get the player
        player = GameObject.FindGameObjectWithTag("Player");

        // Get the game controller script
        gameController = GameObject.Find("Stage").GetComponent<GameController>();

        // Get the ghost scripst
        GameObject[] ghostGameObjects = GameObject.FindGameObjectsWithTag("Ghost");
        ghosts = new Ghost[ghostGameObjects.Length];
        for(int i = 0; i < ghostGameObjects.Length; ++i)
        {
            ghosts[i] = ghostGameObjects[i].GetComponent<Ghost>();
        }

        // Subscribe to the reset event published by the game controller
        // And call this pellet's reset method when it is fired
        gameController.subscribe(GameController.Event.RESET, reset);
    }

    public void reset()
    {
        // Show this pellet
        gameObject.SetActive(true);
    }

    // When this pellet collides with something
    void OnTriggerEnter2D(Collider2D collision)
    {
        // If it collided with the player
        if(collision.gameObject == player)
        {
            // Tell the game controller that a pellet has been eaten
            gameController.pelletEaten(value);

            // Hide this pellet
            this.gameObject.SetActive(false);

            // If there are no more pellets left on the map, reset the level
            if (gameController.PelletsLeft <= 0) gameController.resetLevel();

            // If this pellet happened to be a super pellet
            if(isSuper)
            {
                // Go through each ghost
                foreach(Ghost ghost in ghosts)
                {
                    // And tell them to go into the running state
                    ghost.startRunning();
                }
            }
        }
    }
}
