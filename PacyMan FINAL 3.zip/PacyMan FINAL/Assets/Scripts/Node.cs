﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Represents a node in an A* search
public class Node
{
    // Holds the game object it represents
    public GameObject gameObject;
    public Node parent = null;
    // g is the total distance via this node on a path
    // h is the Euclidean distance to the goal
    public float g = 0, h = 0;
    // f is the total cost of going via this node on a path
    public float f
    {
        get
        {
            return g + h;
        }
    }

    public Node(GameObject gameObject)
    {
        this.gameObject = gameObject;
    }

    // Distance from this node to another game object
    public float distance(GameObject gameObject)
    {
        Vector3 aPos = this.gameObject.transform.localPosition;
        Vector3 bPos = gameObject.transform.localPosition;
        return Vector3.Distance(aPos, bPos);
    }

    // Returns a list of nodes connected to this node
    public List<Node> getSuccessors()
    {
        GameObject[] friends = this.gameObject.GetComponent<Point>().friends;

        List<Node> successors = new List<Node>();

        foreach (GameObject friend in friends)
        {
            Node successor = new Node(friend);
            // Sets each ones parent to this node
            successor.parent = this;

            successors.Add(successor);
        }

        return successors;
    }

    // From a list of nodes, get the node with the lowest overall cost on a path
    public static Node getLowestFNode(List<Node> nodes)
    {
        float lowestF = float.MaxValue;
        Node q = null;
        // Go over each node in the list
        foreach (Node node in nodes)
        {
            // If it's cheaper than anything we've seen before, take note of it
            if (node.f < lowestF)
            {
                lowestF = node.f;
                q = node;
            }
        }
        return q;
    }

    // Given a list of nodes and a game object, returns the node that wraps the game object
    public static Node fromGameObject(List<Node> nodes, GameObject gameObject)
    {
        Node result = null;
        foreach (Node node in nodes)
        {
            if (node.gameObject.Equals(gameObject))
            {
                result = node;
                break;
            }
        }
        return result;
    }
}