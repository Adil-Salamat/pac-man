﻿using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.SceneManagement;

namespace Tests
{
    public class TestAStar
    {
        [UnityTest]
        public IEnumerator TestSearch()
        {
            SceneManager.LoadScene("Main");
            yield return null;
            
            GameObject a = GameObject.Find("Point (38)");
            GameObject b = GameObject.Find("Point (42)");
            GameObject c = GameObject.Find("Point (27)");

            List<GameObject> route = AStar.search(a, c);

            Assert.Contains(b, route);
        }
    }
}
