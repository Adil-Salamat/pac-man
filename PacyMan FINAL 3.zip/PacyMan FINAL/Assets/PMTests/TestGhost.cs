﻿using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.SceneManagement;

namespace Tests
{
    public class TestGhost
    {
        [UnityTest]
        public IEnumerator TestAct()
        {
            SceneManager.LoadScene("Main");
            yield return null;

            GameObject ghost = GameObject.FindGameObjectWithTag("Ghost");
            Ghost controller = ghost.GetComponent<Ghost>();
            controller.act();
            yield return null;

            Assert.AreNotEqual(null, controller.movingToPoint);
        }

        [UnityTest]
        public IEnumerator TestReset()
        {
            SceneManager.LoadScene("Main");
            yield return null;

            GameObject ghost = GameObject.FindGameObjectWithTag("Ghost");
            Ghost controller = ghost.GetComponent<Ghost>();
            controller.reset();
            
            Assert.AreEqual(controller.spawn.transform.localPosition, ghost.transform.localPosition);
        }
    }
}
