﻿using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.SceneManagement;

namespace Tests
{
    public class TestPlayer
    {
        [UnityTest]
        public IEnumerator TestReset()
        {
            SceneManager.LoadScene("Main No Ghost");
            yield return null;

            GameObject pacman = GameObject.FindGameObjectWithTag("Player");
            Player player = pacman.GetComponent<Player>();
            string startPos = player.currentPoint.name;

            while (!Input.GetKeyDown(KeyCode.Return)) yield return null;
            yield return null;

            player.reset();
            yield return null;

            Assert.AreEqual(startPos, player.currentPoint.name);
        }

        [UnityTest]
        public IEnumerator TestRotateFaceSideEffect()
        {
            SceneManager.LoadScene("Main No Ghost");
            yield return null;

            GameObject pacman = GameObject.FindGameObjectWithTag("Player");

            while (!Input.GetKeyDown(KeyCode.UpArrow)) yield return null;
            yield return null;

            Assert.AreEqual(90, pacman.transform.localEulerAngles.z);
        }

        [UnityTest]
        public IEnumerator TestLockToPointSideEffect()
        {
            SceneManager.LoadScene("Main No Ghost");
            yield return null;

            GameObject pacman = GameObject.FindGameObjectWithTag("Player");

            while (!Input.GetKeyDown(KeyCode.Return)) yield return null;
            yield return null;

            float x = pacman.transform.localPosition.x;
            float y = pacman.transform.localPosition.y;
            float z = pacman.transform.localPosition.z;

            bool xIsInt = Mathf.Round(x) - x == 0;
            bool yIsInt = Mathf.Round(y) - y == 0;
            bool zIsInt = Mathf.Round(z) - z == 0;

            Assert.AreEqual(true, xIsInt && yIsInt && zIsInt);
        }

        [UnityTest]
        public IEnumerator TestMoveToPointSideEffect()
        {
            SceneManager.LoadScene("Main No Ghost");
            yield return null;

            GameObject pacman = GameObject.FindGameObjectWithTag("Player");
            Player player = pacman.GetComponent<Player>();
            string startPos = player.currentPoint.name;

            while (!Input.GetKeyDown(KeyCode.Return)) yield return null;
            yield return null;

            Assert.AreNotEqual(startPos, player.currentPoint.name);
        }
    }
}
