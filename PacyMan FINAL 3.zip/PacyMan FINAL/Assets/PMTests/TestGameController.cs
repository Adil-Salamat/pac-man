﻿using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.SceneManagement;

namespace Tests
{
    public class TestGameController
    {
        [UnityTest]
        public IEnumerator TestGameOver()
        {
            SceneManager.LoadScene("Main");
            yield return null;

            GameObject stage = GameObject.Find("Stage");
            GameController controller = stage.GetComponent<GameController>();

            GameObject ghost = GameObject.FindGameObjectWithTag("Ghost");
            Ghost ghostController = ghost.GetComponent<Ghost>();

            controller.gameOver();

            Assert.AreEqual(ghostController.spawn.transform.localPosition, ghost.transform.localPosition);
        }

        [UnityTest]
        public IEnumerator TestResetLevel()
        {
            SceneManager.LoadScene("Main");
            yield return null;
            
            GameObject[] pellets = GameObject.FindGameObjectsWithTag("Pellet");

            GameObject stage = GameObject.Find("Stage");
            GameController controller = stage.GetComponent<GameController>();

            controller.resetLevel();

            Assert.AreEqual(pellets.Length, controller.PelletsLeft - 1);
        }

        [UnityTest]
        public IEnumerator TestPelletEaten()
        {
            SceneManager.LoadScene("Main");
            yield return null;

            GameObject stage = GameObject.Find("Stage");
            GameController controller = stage.GetComponent<GameController>();

            int before = controller.PelletsLeft;
            controller.pelletEaten(1);
            Assert.AreNotEqual(before, controller.PelletsLeft);
        }
    }
}
