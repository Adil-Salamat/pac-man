﻿using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace Tests
{
    public class TestNode
    {
        [Test]
        public void TestF()
        {
            GameObject g = new GameObject();
            Node n = new Node(g);
            n.g = 1;
            n.h = 1;
            Assert.AreEqual(2, n.f);
        }

        [Test]
        public void TestDistance()
        {
            GameObject g1 = new GameObject();
            GameObject g2 = new GameObject();

            g2.transform.localPosition = new Vector3(10, 0, 0);

            Node n1 = new Node(g1);

            Assert.AreEqual(10, n1.distance(g2));
        }

        [Test]
        public void TestGetSuccessors()
        {
            GameObject g1 = new GameObject();
            GameObject g2 = new GameObject();
            
            Point p2 = g2.AddComponent<Point>();
            p2.friends = new GameObject[]
            {
                g1
            };
            
            Node n2 = new Node(g2);
            List<Node> n2Successors = n2.getSuccessors();

            Assert.AreEqual(g1, n2Successors[0].gameObject);
        }

        [Test]
        public void TestGetLowestFNode()
        {
            List<Node> nodes = new List<Node>();

            Node n1 = new Node(new GameObject());
            Node n2 = new Node(new GameObject());
            Node n3 = new Node(new GameObject());

            n1.g = 1;
            n2.g = 2;
            n3.g = 3;

            nodes.Add(n1);
            nodes.Add(n2);
            nodes.Add(n3);

            Assert.AreEqual(n1, Node.getLowestFNode(nodes));
        }

        [Test]
        public void TestFromGameObject()
        {
            List<Node> nodes = new List<Node>();

            GameObject g1 = new GameObject();
            GameObject g2 = new GameObject();
            GameObject g3 = new GameObject();

            Node n1 = new Node(g1);
            Node n2 = new Node(g2);
            Node n3 = new Node(g3);

            nodes.Add(n1);
            nodes.Add(n2);
            nodes.Add(n3);

            Assert.AreEqual(n2, Node.fromGameObject(nodes, g2));
        }
    }
}
